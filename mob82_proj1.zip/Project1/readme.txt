

1. Name: Mohammed Baled



2. Username: mob82



3. Anything that does not work: 

   - I'm not sure if we were meant to implement this but if a user enters a correct letter that is in uppercase my program will not detect that as a match. In other words the program will not crash but in order for the program to function properly the user has to enter lowercase letters.



4. Anything else you think might help the grader grade your project more easily:

   - To turn debug mode on set debug variable to 1 and to turn it off set it to 0 